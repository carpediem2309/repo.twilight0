# -*- coding: utf-8 -*-

"""
    AliveGR Add-on
    Author: Twilight0

        This program is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 3 of the License, or
        (at your option) any later version.

        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.

        You should have received a copy of the GNU General Public License
        along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

action        = None
language      = xbmcaddon.Addon().getLocalizedString
addonName     = xbmcaddon.Addon().getAddonInfo("name")
addonPath     = xbmcaddon.Addon().getAddonInfo("path")
addonDesc     = language(30000).encode("utf-8")
dataPath      = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo("profile")).decode("utf-8")
addonIcon     = os.path.join(addonPath, 'icon.png')
addonArt      = os.path.join(addonPath, 'resources/art')
addonLogos    = os.path.join(addonPath, 'resources/logos')
addonFanart   = os.path.join(addonPath, 'fanart.jpg')
LiveTVimage   = os.path.join(addonArt, 'root_livetv.jpg')
RadioImage    = os.path.join(addonArt, 'radios_all.jpg')
addonChannels = 'https://raw.githubusercontent.com/Twilight0/Channel-Lists/master/alivegr-tv.m3u'
addonRadio    = 'https://raw.githubusercontent.com/Twilight0/Channel-Lists/master/alivegr-radios.m3u'

addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'movies')

LiveTV = xbmcgui.ListItem(language(30001), iconImage=LiveTVimage)
Radio = xbmcgui.ListItem(language(30002), iconImage=RadioImage)

xbmcplugin.addDirectoryItem(handle=addon_handle, url=addonChannels, listitem=LiveTV)
xbmcplugin.endOfDirectory(addon_handle)
xbmcplugin.addDirectoryItem(handle=addon_handle, url=addonRadio, listitem=Radio)
xbmcplugin.endOfDirectory(addon_handle)
